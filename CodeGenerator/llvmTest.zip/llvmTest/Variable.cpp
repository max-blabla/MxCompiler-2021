int s;
int ss = 0;
int sss = 1;
int ssss = ss + s;
int main(){
    int a;
    int b = 0;
    int c = a+b;
    int d = ss + c;
    return ssss+d;
}