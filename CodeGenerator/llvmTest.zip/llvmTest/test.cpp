
int aaaaaaaaa;
int ss;
int dsd[10];
class AA{
public:
    int c = 44;
    int a = 2;
    int g = 3;
    int aaa[12];
};
class A{
public:
    int d = 1;
    int a = 2;
    int g = 3;
    int aaa[12];
    //int * aaa;
    int r(int f){
        return 1;
    }
    AA bbb;
};
A BBB;
AA BBBB;
void f(int a,int b,bool c){
    a = 2;
    return;
}
int main(){
 //   char bb[10];
 //   int a = 2;
 //   A * aa = new A[10];
 //   int aaa[10];
//    aaa[3] = 2;
  //  aa[a].aaa[7] = 1;
 // char aaa[100] = "aaaa";
  A aa;
    aaaaaaaaa = 3;
  //  int ss;
    ss = aaaaaaaaa;
    int ads = ss;
    dsd[0] = ss;
//  f(1);
}