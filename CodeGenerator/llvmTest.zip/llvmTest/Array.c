
int arr1[100] ={0};
int arr2[123] = {0};
int * arr3;
int main(){
    arr1[2] = 0;
    arr2[3] = 1;
    arr2[3] = arr1[1];
    arr3 = (int *) malloc(52);
    int * arr4;
    arr4 = (int *) malloc(92);
    arr4 = arr2;
    int arr5[232];
}