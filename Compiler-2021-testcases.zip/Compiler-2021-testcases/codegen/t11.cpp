/*
Test Package: Codegen
Author: Admin
Time: 2020-01-25
Input:
=== input ===
=== end ===
Output:
=== output ===
=== end ===
ExitCode: 55
InstLimit: -1
Origin Package: Codegen Pretest-538
*/

int main() {
    int n = 10;
    int f0 = 0;
    int f1 = 1;
    int f2;
    int i;
    for (i = 1; i < n; ++i) {
        f2 = f0 + f1;
        f0 = f1;
        f1 = f2;
    }
    return f2;
}