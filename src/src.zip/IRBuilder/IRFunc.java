package IRBuilder;

import java.util.List;

class IRFunc{
    String FuncName;
    String RetType;
    List<IRBlock> BlockList;
    void NewIRBlock(String Label){
        IRBlock NewBlock  = new IRBlock();
        NewBlock.Label = Label;
        BlockList.add(NewBlock);
    }
    public IRBlock getTopBlock(){
        return BlockList.get(BlockList.size() - 1);
    }
}