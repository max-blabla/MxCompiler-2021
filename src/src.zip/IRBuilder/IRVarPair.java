package IRBuilder;

import ASTNode.ExprAST;

public class IRVarPair{
    String Type;
    String Name;
    ExprAST Expr;
}
