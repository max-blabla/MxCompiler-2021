package IRBuilder;

import ASTNode.*;

import java.util.Stack;
import java.util.List;
class Scope{
    String ScopeName;
    Scope(String scopeName){
        ScopeName = scopeName;
    }
};

public class IRBuilder{
    GlobalAST Program;
    Stack<Scope> ScopeStack;
    List<IRModule> ModuleList;

    void ProgramIR(){

        IRModule GlobalModule = new IRModule();
        GlobalModule.setName("");
        Scope NewScope = new Scope("global");
        ScopeStack.push(NewScope);
        ModuleList.add(GlobalModule);
        for(DeclAST Decl:Program.DeclList) DeclIR(Decl);
        ScopeStack.pop();

    }

    void DeclIR(DeclAST DeclNode){
        if(DeclNode instanceof VarDeclAST)  VarDeclIR(DeclNode);
        else if(DeclNode instanceof FuncDeclAST) FuncDeclIR(DeclNode);
        else ClassDeclIR(DeclNode);
    }

    //
    void VarDeclIR(DeclAST VarDeclNode){
        VarDeclAST VarNode = (VarDeclAST) VarDeclNode;
        List<VarDeclareAST> VarDeclList = VarNode.getVarDeclareList();
        IRModule TopModule = ModuleList.get(ModuleList.size()-1);
        for(VarDeclareAST VarDecl : VarDeclList){
            IRVarPair irVarPair = new IRVarPair();
            irVarPair.Type = VarNode.getType();
            irVarPair.Name = VarDecl.getId();
            irVarPair.Expr = VarDecl.getExpr();
            TopModule.VarInsert(irVarPair);
        }
    }

    void FuncDeclIR(DeclAST FuncDeclNode){
        FuncDeclAST FuncNode = (FuncDeclAST) FuncDeclNode;
        IRModule TopModule = ModuleList.get(ModuleList.size()-1);
        List<StmtAST> StmtList = FuncNode.getStmtList();
        IRFunc NewFunc = new IRFunc();
        NewFunc.FuncName = FuncNode.getFuncName();
        NewFunc.RetType = FuncNode.getFuncType();
        NewFunc.NewIRBlock("Start");
        TopModule.FuncInsert(NewFunc);
        //还有函数参数块
        FuncScope NewScope = new FuncScope();
        ScopeStack.push(NewScope);
        for(StmtAST Stmt : StmtList) StmtIR(Stmt);
        ScopeStack.pop();
    }

    void StmtIR(StmtAST StmtNode){
        if(StmtNode instanceof JumpStmtAST)  JumpStmtIR(StmtNode);
        else if(StmtNode instanceof ReturnStmtAST) ReturnStmtIR(StmtNode);
        else if(StmtNode instanceof  WhileStmtAST) WhileStmtIR(StmtNode);
        else if(StmtNode instanceof IfStmtAST) IfStmtIR(StmtNode);
        else if(StmtNode instanceof ExprStmtAST) ExprStmtIR(StmtNode);
        else if(StmtNode instanceof ForStmtAST) ForStmtIR(StmtNode);
        else if(StmtNode instanceof SuiteAST) SuiteIR(StmtNode);
        else VarStmtIR(StmtNode);
    }

    void ClassDeclIR(DeclAST ClassDeclNode){
        ClassDeclAST ClassNode = (ClassDeclAST) ClassDeclNode;

        IRModule ClassModule = new IRModule();
        ClassModule.setName(ClassNode.getClassName());
        ModuleList.add(ClassModule);

        ClassScope NewScope = new ClassScope();
        ScopeStack.push(NewScope);
        for(DeclAST Decl:Program.DeclList) DeclIR(Decl);
        ScopeStack.pop();
    }

    //记得加封禁判断
    void JumpStmtIR(StmtAST JumpStmtNode){
        //或者让后面的无法加入
        IRBlock TopBlock = ModuleList.get(ModuleList.size()-1).getTopBlock();
        if(!TopBlock.isShut()) TopBlock.ShutBlock();
    }

    void ReturnStmtIR(StmtAST ReturnStmtNode){
        IRBlock TopBlock = ModuleList.get(ModuleList.size()-1).getTopBlock();
        ReturnStmtAST ReturnStmt = (ReturnStmtAST) ReturnStmtNode;
        if(!TopBlock.isShut()) {
            if(ReturnStmt.getExpr() != null) TopBlock.InsertExpr(ReturnStmt.getExpr());
            TopBlock.ShutBlock();
        }
    }

    void WhileStmtIR(StmtAST WhileStmtNode){
        WhileStmtAST WhileStmt = (WhileStmtAST) WhileStmtNode;
        IRFunc irFunc = ModuleList.get(ModuleList.size()-1).getTopFunc();
        irFunc.NewIRBlock("While-Condition");
        irFunc.getTopBlock().InsertExpr(WhileStmt.getConditionExpr());
        irFunc.NewIRBlock("While-Body");
        StmtIR(WhileStmt.getLoopStmt());
    }

    void IfStmtIR(StmtAST IfStmtNode){
        IfStmtAST IfStmt = (IfStmtAST) IfStmtNode;
        IRFunc irFunc = ModuleList.get(ModuleList.size()-1).getTopFunc();
        irFunc.NewIRBlock("If-Condition");
        irFunc.getTopBlock().InsertExpr(IfStmt.getConditionExpr());
        irFunc.NewIRBlock("If-True-Stmt");
        StmtIR(IfStmt.getTrueStmt());
        irFunc.NewIRBlock("If-False-Stmt");
        StmtIR(IfStmt.getFalseStmt());
    }

    void ForStmtIR(StmtAST ForStmtNode){
        ForStmtAST ForStmt = (ForStmtAST) ForStmtNode;
        IRFunc irFunc = ModuleList.get(ModuleList.size()-1).getTopFunc();
        irFunc.NewIRBlock("For-Init");
        if(ForStmt.getInitStmt() != null){
            irFunc.getTopBlock().InsertExpr();
        }
        else irFunc.getTopBlock().InsertExpr(ForStmt.getInitExpr());

        irFunc.NewIRBlock("For-Condition");
        irFunc.getTopBlock().InsertExpr(ForStmt.getConditionExpr());
        irFunc.NewIRBlock("For-Loop");
        StmtIR(ForStmt.getLoopStmt());
        irFunc.getTopBlock().InsertExpr(ForStmt.getIncrExpr());
    }

    void ExprStmtIR(StmtAST ExprStmtNode){
        ExprStmtAST ExprStmt = (ExprStmtAST) ExprStmtNode;
        IRFunc irFunc = ModuleList.get(ModuleList.size()-1).getTopFunc();
        irFunc.getTopBlock().InsertExpr(ExprStmt.getExpr());
    }

    void SuiteIR(StmtAST SuiteNode){
        SuiteAST Suite = (SuiteAST) SuiteNode;
        List<StmtAST> StmtList = Suite.getStmtList();
        for(StmtAST Stmt : StmtList) StmtIR(Stmt);
    }

    void VarStmtIR(StmtAST VarStmtNode){
        VarStmtAST VarStmt = (VarStmtAST) VarStmtNode;

    }


}