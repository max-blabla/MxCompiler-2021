package IRBuilder;

import java.util.HashSet;
import java.util.HashMap;
import java.util.List;


public class IRModule{
    String Name;
    HashMap<String, IRVarPair> VarTable;
    List<IRFunc> FuncSet;
    public void VarInsert(IRVarPair varPair){
        VarTable.put(varPair.Name, varPair);
    }
    public void FuncInsert(){

    }
    public void setName(String name){
        Name = name;
    }
    public IRBlock getTopBlock(){
        return FuncSet.get(FuncSet.size()-1).getTopBlock();
    }
    public IRFunc getTopFunc(){ return FuncSet.get(FuncSet.size() - 1);}
}