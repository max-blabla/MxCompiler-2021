package IRBuilder;

import ASTNode.ExprAST;
import ASTNode.VarDeclAST;
import ASTNode.VarDeclareAST;

import java.util.List;

class VarDeclPair{
    String Type;
    VarDeclareAST VarDeclare;
}
public class IRBlock{
    String Label;
    List<ExprAST> ExprList;
    List<VarDeclPair> VarDeclList;
    Boolean shutFlag;
    public void ShutBlock(){
        shutFlag = true;
    }

    public boolean isShut(){
        return shutFlag;
    }
    public void InsertExpr(ExprAST Expr){
        ExprList.add(Expr);
    }
    public void InsertVarDecl(VarDeclareAST VarDeclare, String Type){
        VarDeclPair NewPair = new VarDeclPair();
        NewPair.Type = Type;
        NewPair.VarDeclare = VarDeclare;
        VarDeclList.add(NewPair);
    }
}