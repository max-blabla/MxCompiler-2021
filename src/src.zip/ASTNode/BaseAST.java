package ASTNode;

abstract public class BaseAST {
    public BaseAST Father;
    abstract public void InsertSon(BaseAST Son);
   // abstract public void Print();
}
