package ASTNode;
abstract public class DeclAST extends BaseAST{

}