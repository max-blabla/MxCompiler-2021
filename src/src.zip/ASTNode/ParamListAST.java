package ASTNode;

import java.util.List;

public class ParamListAST extends BaseAST{
    List<TypeAST> ParamTypeList;
    List<IdAST> ParamLabelList;
    public ParamListAST(List<TypeAST> typeList, List<IdAST> labelList){
        ParamTypeList = typeList;
        ParamLabelList = labelList;
    }
    @Override
    public void InsertSon(BaseAST Son) {
        new BuildError("ParamListAST","InsertSon","Wrong Build");
    }
}
