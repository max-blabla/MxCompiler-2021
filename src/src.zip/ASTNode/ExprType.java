package ASTNode;

public enum ExprType{
        Assign,
        FuncCall,
        Lambda,
        MemCall,
        Index,
        Positive,
        Negative,
        SelfPlus,
        SelfMinus,
        Plus,
        Minus,
        Multiply,
        Divide,
        Mod,
        Not,
        Tidle
};