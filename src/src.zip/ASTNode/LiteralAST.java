package ASTNode;

public class LiteralAST extends BaseAST{
    String Type;
    String Context;

    public LiteralAST(String type, String context){
        Type = type;
        Context = context;
    }

    @Override
    public void InsertSon(BaseAST Son) {
        new BuildError("LiteralAST","InsertSon","");
    }
}
