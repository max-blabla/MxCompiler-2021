package ASTNode;
public class EmptyStmtAST extends StmtAST{
};