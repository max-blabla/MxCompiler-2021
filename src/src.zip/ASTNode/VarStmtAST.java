package ASTNode;

public class VarStmtAST extends StmtAST{
    VarDeclAST VarDecl;

    @Override
    public void InsertSon(BaseAST Son) {
        VarDecl  = (VarDeclAST) Son;
        VarDecl.Father = this;
    }
}
