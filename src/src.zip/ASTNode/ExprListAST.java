package ASTNode;

import java.util.List;

public class ExprListAST extends BaseAST{
    List<ExprAST> ExprList;

    public ExprListAST(){}

    @Override
    public void InsertSon(BaseAST Son) {
        if(Son instanceof ExprAST){
            ExprAST NewExpr = (ExprAST) Son;
            NewExpr.Father = this;
            ExprList.add(NewExpr);
        }
        else new BuildError("ExprListAST","InsertSon","");
    }
}