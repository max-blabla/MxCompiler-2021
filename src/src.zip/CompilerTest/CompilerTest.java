<<<<<<< HEAD
package CompilerTest;

import GlobalVisitor.GlobalVisitor;
import GlobalVisitor.TypeVisitor;
import MxParser.MxParser;
import SemanticChecker.SemanticChecker;
import org.antlr.v4.runtime.ANTLRInputStream;
import MxParser.MxLexer;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.RecognitionException;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

import java.io.*;
import java.util.Vector;

public class CompilerTest {

}
=======
package CompilerTest;

import GlobalVisitor.GlobalVisitor;
import GlobalVisitor.TypeVisitor;
import MxParser.MxParser;
import SemanticChecker.SemanticChecker;
import org.antlr.v4.runtime.ANTLRInputStream;
import MxParser.MxLexer;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.RecognitionException;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

import java.io.*;
import java.util.Vector;

public class CompilerTest {

}
>>>>>>> 4c773d54cd780b6299f59d705f4124f10145b5a4
