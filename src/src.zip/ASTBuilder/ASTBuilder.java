package ASTBuilder;
import ASTNode.*;
import MxParser.MxBaseListener;
import MxParser.MxParser;

import java.util.Objects;

//首先要有一个类型表
public class ASTBuilder extends MxBaseListener{
    GlobalAST AST;
    BaseAST CurASTNode;
    TypeMap TypeTable;
    @Override
    public void enterProgram(MxParser.ProgramContext ctx){
        AST = new GlobalAST();
        CurASTNode = AST;
    }

    @Override
    public void enterFuncDef(MxParser.FuncDefContext ctx){
        FuncDeclAST NewDef = new FuncDeclAST();
        CurASTNode.InsertSon(NewDef);
        CurASTNode = NewDef;
    }

    @Override
    public void exitFuncDef(MxParser.FuncDefContext ctx){
        CurASTNode = CurASTNode.Father;
    }

   // public void enterParameterList(MxParser.ParameterListContext ctx) { }
   // public void exitParameterList(MxParser.ParameterListContext ctx) { CurASTNode = CurASTNode.Father }

    @Override
    public void enterClassDef(MxParser.ClassDefContext ctx){
        ClassDeclAST NewDef = new ClassDeclAST();
        CurASTNode.InsertSon(NewDef);
        CurASTNode = NewDef;
    }

    @Override
    public void exitClassDef(MxParser.ClassDefContext ctx){
        CurASTNode = CurASTNode.Father;
    }

    @Override
    public void enterVarDef(MxParser.VarDefContext ctx) {
        VarDeclAST NewDef = new VarDeclAST();
        CurASTNode.InsertSon(NewDef);
        CurASTNode = NewDef;
    }

    @Override
    public void exitVarDef(MxParser.VarDefContext ctx){
        CurASTNode = CurASTNode.Father;
    }

    @Override
    public void enterVarDeclaration(MxParser.VarDeclarationContext ctx) {
        String VarName = ctx.Identifier().toString();
        IdAST VarId = new IdAST(VarName);
        VarDeclareAST NewDecl = new VarDeclareAST(VarId);
        CurASTNode.InsertSon(NewDecl);
        CurASTNode = NewDecl;
    }
    @Override
    public void exitVarDeclaration(MxParser.VarDeclarationContext ctx){
        CurASTNode = CurASTNode.Father;
    }

    @Override
    public void enterSuite(MxParser.SuiteContext ctx){
        SuiteAST NewSuite = new SuiteAST();
        CurASTNode.InsertSon(NewSuite);
        CurASTNode = NewSuite;
    }

    @Override
    public void exitSuite(MxParser.SuiteContext ctx){
        CurASTNode = CurASTNode.Father;
    }

    @Override
    public void enterIfStatement(MxParser.IfStatementContext ctx) {
        IfStmtAST NewStmt = new IfStmtAST();
        CurASTNode.InsertSon(NewStmt);
        CurASTNode = NewStmt;
    }

    @Override
    public void exitIfStatement(MxParser.IfStatementContext ctx) { CurASTNode = CurASTNode.Father;}


    @Override public void enterCondition(MxParser.ConditionContext ctx) {
        ConditionAST Condition = new ConditionAST();
        CurASTNode.InsertSon(Condition);
        CurASTNode = Condition;
    }

    @Override
    public void exitCondition(MxParser.ConditionContext ctx) {CurASTNode = CurASTNode.Father;}

    @Override
    public void enterForInit(MxParser.ForInitContext ctx) {
        ForInitAST NewStmt = new ForInitAST();
        CurASTNode.InsertSon(NewStmt);
        CurASTNode = NewStmt;
    }

    @Override
    public void exitForInit(MxParser.ForInitContext ctx) { CurASTNode = CurASTNode.Father; }

    @Override
    public void enterForStatement(MxParser.ForStatementContext ctx) {
        ForStmtAST NewStmt = new ForStmtAST();
        CurASTNode.InsertSon(NewStmt);
        CurASTNode = NewStmt;
    }

    @Override
    public void exitForStatement(MxParser.ForStatementContext ctx) {  CurASTNode = CurASTNode.Father;}

    @Override
    public void enterWhileStatement(MxParser.WhileStatementContext ctx) {
        WhileStmtAST NewStmt = new WhileStmtAST();
        CurASTNode.InsertSon(NewStmt);
        CurASTNode = NewStmt;
    }

    @Override
    public void exitWhileStatement(MxParser.WhileStatementContext ctx) { CurASTNode = CurASTNode.Father; }

    @Override
    public void enterReturnStatement(MxParser.ReturnStatementContext ctx) {
        ReturnStmtAST NewStmt = new ReturnStmtAST();
        CurASTNode.InsertSon(NewStmt);
        CurASTNode = NewStmt;
    }

    @Override
    public void exitReturnStatement(MxParser.ReturnStatementContext ctx) { CurASTNode = CurASTNode.Father; }

    @Override
    public void enterJumpStatement(MxParser.JumpStatementContext ctx) {
        JumpStmtAST NewStmt;
        if(ctx.Break() == null) NewStmt = new JumpStmtAST(Boolean.FALSE);
        else NewStmt = new JumpStmtAST(Boolean.TRUE);
        CurASTNode.InsertSon(NewStmt);
        CurASTNode = NewStmt;
    }

    @Override
    public void exitJumpStatement(MxParser.JumpStatementContext ctx) { CurASTNode = CurASTNode.Father; }

    @Override
    public void enterExprStatement(MxParser.ExprStatementContext ctx){

    }

    @Override
    public void enterExpression(MxParser.ExpressionContext ctx) {
        //在这里的默认构造要传进去表达式类型
        ExprType Type;
        if(ctx.lambdaExpression() != null) Type = ExprType.Lambda;
        else if(ctx.LeftParenthes() != null) Type = ExprType.FuncCall;
        else if(ctx.indexExpr() != null) Type = ExprType.Index;
        else if(ctx.Dot() != null) Type = ExprType.MemCall;
        else if(ctx.Plus() != null){
            if(ctx.expression().size() == 1) Type = ExprType.Positive;
            else Type = ExprType.Plus;
        }
        else if(ctx.Minus()!=null){
            if(ctx.expression().size() == 1) Type = ExprType.Negative;
            else Type = ExprType.Minus;
        }
        else if(ctx.Not() != null) Type = ExprType.Not;
        else if(ctx.Tidle() != null) Type = ExprType.Tidle;
        else if(ctx.SelfMinus() != null){

        }
        ExprAST NewExpr = new ExprAST();
        CurASTNode.InsertSon(NewExpr);
        CurASTNode = NewExpr;
    }

    @Override
    public void exitExpression(MxParser.ExpressionContext ctx) { CurASTNode = CurASTNode.Father; }

    @Override
    public void enterExpressionList(MxParser.ExpressionListContext ctx) {
        ExprListAST NewExprList = new ExprListAST();
        CurASTNode.InsertSon(NewExprList);
        CurASTNode = NewExprList;
    }
    @Override
    public void exitExpressionList(MxParser.ExpressionListContext ctx) { CurASTNode = CurASTNode.Father; }

    @Override
    public void enterLambdaExpression(MxParser.LambdaExpressionContext ctx) {
        LambdaExprAST NewLambda = new LambdaExprAST();
        CurASTNode.InsertSon(NewLambda);
        CurASTNode = NewLambda;
    }

    @Override
    public void exitLambdaExpression(MxParser.LambdaExpressionContext ctx) { CurASTNode = CurASTNode.Father; }

    @Override
    public void enterType(MxParser.TypeContext ctx) {
        TypeAST NewType = new TypeAST(ctx.getText());
        CurASTNode.InsertSon(NewType);
        CurASTNode = NewType;
    }
    @Override
    public void exitType(MxParser.TypeContext ctx) { CurASTNode = CurASTNode.Father;  }
    @Override
    public void enterLiteral(MxParser.LiteralContext ctx) {
        String Context  = ctx.getText();
        String LiteralType;
        if(Objects.equals(Context, "True") || Objects.equals(Context, "False")) LiteralType = "bool";
        else if(Objects.equals(Context, "Null")) LiteralType = "auto";
        else if(Context.charAt(0)<='9' && Context.charAt(0) >= '0') LiteralType = "int";
        else LiteralType = "string";
        LiteralAST NewLiteral = new LiteralAST(LiteralType,Context);
        CurASTNode.InsertSon(NewLiteral);
        CurASTNode = NewLiteral;
    }
    @Override
    public void exitLiteral(MxParser.LiteralContext ctx) { CurASTNode = CurASTNode.Father; }
    @Override
    public void enterLabel(MxParser.LabelContext ctx) {
        String LabelName = ctx.getText();
        IdAST NewLabel = new IdAST(LabelName);
        CurASTNode.InsertSon(NewLabel);
        CurASTNode = NewLabel;
    }
    @Override
    public void exitLabel(MxParser.LabelContext ctx) { CurASTNode = CurASTNode.Father; }
}