<<<<<<< HEAD
package  SemanticChecker;
public class R_VarInfo{
    Integer Type;
    Boolean IsNull;
    public R_VarInfo(Integer type, Boolean isNull){
        Type = type;
        IsNull = isNull;
    }
=======
package  SemanticChecker;
public class R_VarInfo{
    Integer Type;
    Boolean IsNull;
    public R_VarInfo(Integer type, Boolean isNull){
        Type = type;
        IsNull = isNull;
    }
>>>>>>> 4c773d54cd780b6299f59d705f4124f10145b5a4
}