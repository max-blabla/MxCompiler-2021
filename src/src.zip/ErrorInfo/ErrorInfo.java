<<<<<<< HEAD
package ErrorInfo;

public class ErrorInfo {
    String Info;
    public ErrorInfo(String Info, String CtxText){
        this.Info = Info;
      //  System.out.print("[Error] ");
      //  System.out.println(Info);
    }
}
=======
package ErrorInfo;

public class ErrorInfo {
    String Info;
    public ErrorInfo(String Info, String CtxText){
        this.Info = Info;
      //  System.out.print("[Error] ");
      //  System.out.println(Info);
    }
}
>>>>>>> 4c773d54cd780b6299f59d705f4124f10145b5a4
